package com.practica.jdbc.modelo;

import java.time.LocalDate;

public class ExcusaEntrega {
    
    private int id;
    private String alumno;
    private String curso;
    private String excusa;
    private int dias_retraso;
    private int credibilidad;
    private LocalDate fechaEntrega;
    private boolean aprobadaPorProfesor;
    private int nivelDrama;

    public ExcusaEntrega() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAlumno() {
        return alumno;
    }

    public void setAlumno(String alumno) {
        this.alumno = alumno;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getExcusa() {
        return excusa;
    }

    public void setExcusa(String excusa) {
        this.excusa = excusa;
    }

    public int getDias_retraso() {
        return dias_retraso;
    }

    public void setDias_retraso(int dias_retraso) {
        this.dias_retraso = dias_retraso;
    }

    public int getCredibilidad() {
        return credibilidad;
    }

    public void setCredibilidad(int credibilidad) {
        this.credibilidad = credibilidad;
    }

    public LocalDate getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(LocalDate fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public boolean isAprobadaPorProfesor() {
        return aprobadaPorProfesor;
    }

    public void setAprobadaPorProfesor(boolean aprobadaPorProfesor) {
        this.aprobadaPorProfesor = aprobadaPorProfesor;
    }

    public int getNivelDrama() {
        return nivelDrama;
    }

    public void setNivelDrama(int nivelDrama) {
        this.nivelDrama = nivelDrama;
    }

    @Override
    public String toString() {
        return "ExcusaEntrega [id=" + id + ", alumno=" + alumno + ", curso=" + curso + ", excusa=" + excusa
                + ", dias_retraso=" + dias_retraso + ", credibilidad=" + credibilidad + ", fechaEntrega=" + fechaEntrega
                + ", aprobadaPorProfesor=" + aprobadaPorProfesor + ", nivelDrama=" + nivelDrama + "]";
    }

    

}
