package com.practica.jdbc.dao;

import com.practica.jdbc.conexion.ConexionBD;
import com.practica.jdbc.modelo.ExcusaEntrega;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ExcusaDAO {
    public List<ExcusaEntrega> consultaBasica() throws SQLException {
        String sql = "select alumno, excusa, dias_retraso, nivel_drama "
                + "from excusa_entrega order by nivel_drama desc";

        List<ExcusaEntrega> lista = new ArrayList<>();

        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                ExcusaEntrega e = new ExcusaEntrega();
                e.setAlumno(rs.getString("alumno"));
                e.setExcusa(rs.getString("excusa"));
                e.setDias_retraso(rs.getInt("dias_retraso"));
                e.setNivelDrama(rs.getInt("nivel_drama"));
                lista.add(e);
            }
        }

        return lista;
    }

    // Convierte la fila actual del ResultSet en un objeto (todas las columnas)
    private ExcusaEntrega mapear(ResultSet rs) throws SQLException {
        ExcusaEntrega e = new ExcusaEntrega();
        e.setId(rs.getInt("id"));
        e.setAlumno(rs.getString("alumno"));
        e.setCurso(rs.getString("curso"));
        e.setExcusa(rs.getString("excusa"));
        e.setDias_retraso(rs.getInt("dias_retraso"));
        e.setCredibilidad(rs.getInt("credibilidad"));
        Date fecha = rs.getDate("fecha_entrega");
        e.setFechaEntrega(fecha == null ? null : fecha.toLocalDate());
        e.setAprobadaPorProfesor(rs.getBoolean("aprobada_por_profesor"));
        e.setNivelDrama(rs.getInt("nivel_drama"));
        return e;
    }

    // Consulta 2: LIKE + BETWEEN
    public List<ExcusaEntrega> consultaLikeBetween() throws SQLException {
        String sql = "SELECT * FROM excusa_entrega "
                   + "WHERE (excusa LIKE ? OR excusa LIKE ?) "
                   + "AND dias_retraso BETWEEN ? AND ? "
                   + "ORDER BY dias_retraso DESC";

        List<ExcusaEntrega> lista = new ArrayList<>();
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%perro%");
            ps.setString(2, "%gato%");
            ps.setInt(3, 2);
            ps.setInt(4, 6);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    // Consulta 3: IS NULL
    public List<ExcusaEntrega> consultaIsNull() throws SQLException {
        String sql = "SELECT * FROM excusa_entrega "
                   + "WHERE fecha_entrega IS NULL "
                   + "AND (credibilidad < ? OR nivel_drama >= ?)";

        List<ExcusaEntrega> lista = new ArrayList<>();
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, 4);
            ps.setInt(2, 9);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    // Consulta 4: avanzada
    public List<ExcusaEntrega> consultaAvanzada() throws SQLException {
        String sql = "SELECT * FROM excusa_entrega "
                   + "WHERE (nivel_drama >= ? AND credibilidad <= ?) "
                   + "OR (dias_retraso BETWEEN ? AND ? AND excusa LIKE ?) "
                   + "ORDER BY nivel_drama DESC, dias_retraso DESC";

        List<ExcusaEntrega> lista = new ArrayList<>();
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, 8);
            ps.setInt(2, 3);
            ps.setInt(3, 2);
            ps.setInt(4, 5);
            ps.setString(5, "%perro%");

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }
}