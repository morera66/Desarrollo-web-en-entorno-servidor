package com.practica.jdbc;

import com.practica.jdbc.dao.ExcusaDAO;
import com.practica.jdbc.modelo.ExcusaEntrega;

import java.sql.SQLException;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        ExcusaDAO dao = new ExcusaDAO();

        try {
            System.out.println("===== 1. CONSULTA BÁSICA =====");
            List<ExcusaEntrega> lista = dao.consultaBasica();
            for (ExcusaEntrega e : lista) {
                System.out.println(e.getAlumno() + " | " + e.getExcusa()
                        + " | retraso=" + e.getDias_retraso()
                        + " | drama=" + e.getNivelDrama());
            }
            System.out.println("Total: " + lista.size());

            mostrar("2. CONSULTA LIKE + BETWEEN", dao.consultaLikeBetween());
            mostrar("3. CONSULTA IS NULL", dao.consultaIsNull());
            mostrar("4. CONSULTA AVANZADA", dao.consultaAvanzada());

        } catch (SQLException ex) {
            System.err.println("Error de base de datos: " + ex.getMessage());
        }
    }

    private static void mostrar(String titulo, List<ExcusaEntrega> lista) {
        System.out.println();
        System.out.println("===== " + titulo + " =====");
        for (ExcusaEntrega e : lista) {
            System.out.println(e);
        }
        System.out.println("Total: " + lista.size());
    }
}