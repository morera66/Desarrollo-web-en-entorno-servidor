package com.practica.jdbc.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConexionBD {
    private static final String URL = "jdbc:mysql://127.0.0.1:3336/excusa_entrega";
    private static final String USUARIO = "root";
    private static final String PASSWORD = "root1234";


    public static Connection getConexion() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }
}
